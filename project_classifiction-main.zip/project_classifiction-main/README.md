# Fetal Health for Classification Project
Project idea: Studying the condition of the fetus in the mother’s womb to diagnose its health status (normal, abnormal) based on several measured factors such as its heart rate, movement rate, slowing rate of fetal movement for a long time, and others to predict its health status, whether it is normal or abnormal. In this project, we created a model to classify Fetus health.

